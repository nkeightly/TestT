#   OPSC 7311 SUBMISSION
# Git Command Cheat Sheet

## Setup
- Initialize a new Git repository in the current directory:
  ```bash
  git init

## Cloning into Project Files
git clone <repository_url>

## Add changes to the staging area:
git add <file_name>

## View Contents of file:
type test.txt

## Create file
echo Hello, this is a test file. > test.txt

## Commit changes to the repository:
git commit -m "Commit message"

## Push changes to a remote repository:
git push origin <branch_name>

## Pull changes from a remote repository:
git pull origin <branch_name>

## Discard changes in the working directory:
git checkout -- <file_name>

## Undo the last commit and move changes back to the staging area:
git reset HEAD^

## View remote repositories:
git remote -v

## Rename a branch:
git branch -m <old_branch_name> <new_branch_name>


## View Commit History:
git log

## More Detailed Commit History:
git log --stat
